﻿namespace JP_Surplus
{
    partial class Edit2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonUpdate = new Button();
            txtProductID = new TextBox();
            txtUpdateInput = new TextBox();
            button1 = new Button();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton5 = new RadioButton();
            button3 = new Button();
            buttonDelete = new Button();
            btnAdd = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // buttonUpdate
            // 
            buttonUpdate.BackColor = Color.FromArgb(221, 0, 44);
            buttonUpdate.Font = new Font("Stencil", 12F);
            buttonUpdate.ForeColor = SystemColors.ControlLightLight;
            buttonUpdate.Location = new Point(485, 340);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(90, 37);
            buttonUpdate.TabIndex = 1;
            buttonUpdate.Text = "Update";
            buttonUpdate.UseVisualStyleBackColor = false;
            buttonUpdate.Click += buttonUpdate_Click;
            // 
            // txtProductID
            // 
            txtProductID.Font = new Font("Stencil", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtProductID.Location = new Point(127, 307);
            txtProductID.Name = "txtProductID";
            txtProductID.Size = new Size(51, 23);
            txtProductID.TabIndex = 2;
            // 
            // txtUpdateInput
            // 
            txtUpdateInput.Font = new Font("Stencil", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUpdateInput.Location = new Point(157, 349);
            txtUpdateInput.Name = "txtUpdateInput";
            txtUpdateInput.Size = new Size(267, 23);
            txtUpdateInput.TabIndex = 3;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(221, 0, 44);
            button1.Font = new Font("Stencil", 12F);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(587, 340);
            button1.Name = "button1";
            button1.Size = new Size(90, 37);
            button1.TabIndex = 4;
            button1.Text = "Load";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Stencil", 9.75F);
            radioButton1.ForeColor = SystemColors.ControlLightLight;
            radioButton1.Location = new Point(23, 391);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(60, 20);
            radioButton1.TabIndex = 6;
            radioButton1.TabStop = true;
            radioButton1.Text = "Name";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Stencil", 9.75F);
            radioButton2.ForeColor = SystemColors.ControlLightLight;
            radioButton2.Location = new Point(95, 391);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(88, 20);
            radioButton2.TabIndex = 7;
            radioButton2.TabStop = true;
            radioButton2.Text = "Quantity";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Font = new Font("Stencil", 9.75F);
            radioButton3.ForeColor = SystemColors.ControlLightLight;
            radioButton3.Location = new Point(186, 391);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(57, 20);
            radioButton3.TabIndex = 8;
            radioButton3.TabStop = true;
            radioButton3.Text = "Inch";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Font = new Font("Stencil", 9.75F);
            radioButton4.ForeColor = SystemColors.ControlLightLight;
            radioButton4.Location = new Point(252, 391);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(108, 20);
            radioButton4.TabIndex = 9;
            radioButton4.TabStop = true;
            radioButton4.Text = "Description";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Font = new Font("Stencil", 9.75F);
            radioButton5.ForeColor = SystemColors.ControlLightLight;
            radioButton5.Location = new Point(361, 391);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(63, 20);
            radioButton5.TabIndex = 10;
            radioButton5.TabStop = true;
            radioButton5.Text = "Price";
            radioButton5.UseVisualStyleBackColor = true;
            radioButton5.CheckedChanged += radioButton5_CheckedChanged;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(221, 0, 44);
            button3.Font = new Font("Stencil", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.ControlLightLight;
            button3.Location = new Point(668, 391);
            button3.Name = "button3";
            button3.Size = new Size(111, 41);
            button3.TabIndex = 11;
            button3.Text = "MAIN PAGE";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = Color.FromArgb(221, 0, 44);
            buttonDelete.Font = new Font("Stencil", 12F);
            buttonDelete.ForeColor = SystemColors.ControlLightLight;
            buttonDelete.Location = new Point(689, 340);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(90, 37);
            buttonDelete.TabIndex = 12;
            buttonDelete.Text = "DELETE";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(221, 0, 44);
            btnAdd.Font = new Font("Stencil", 12F);
            btnAdd.ForeColor = SystemColors.ControlLightLight;
            btnAdd.Location = new Point(540, 391);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(90, 37);
            btnAdd.TabIndex = 13;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Stencil", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(23, 310);
            label1.Name = "label1";
            label1.Size = new Size(101, 18);
            label1.TabIndex = 14;
            label1.Text = "PRODUCT ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Stencil", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(21, 348);
            label2.Name = "label2";
            label2.Size = new Size(130, 18);
            label2.TabIndex = 15;
            label2.Text = "PRODUCT INPUT:";
            // 
            // Edit2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(11, 33, 54);
            ClientSize = new Size(809, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnAdd);
            Controls.Add(buttonDelete);
            Controls.Add(button3);
            Controls.Add(radioButton5);
            Controls.Add(radioButton4);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(button1);
            Controls.Add(txtUpdateInput);
            Controls.Add(txtProductID);
            Controls.Add(buttonUpdate);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Edit2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EDIT STOCKS";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonUpdate;
        private TextBox txtProductID;
        private TextBox txtUpdateInput;
        private Button button1;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private RadioButton radioButton5;
        private Button button3;
        private Button buttonDelete;
        private Button btnAdd;
        private Label label1;
        private Label label2;
    }
}